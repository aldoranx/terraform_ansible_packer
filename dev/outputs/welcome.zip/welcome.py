import json
import boto3


def hello(event, context):
    print ("Welcome to My World")

module.exports.handler = async (event) => {
   console.log('Event: ', event)
   let responseMessage = 'Hello, World!';

+  if (event.queryStringParameters && event.queryStringParameters['Name']) {
+    responseMessage = 'Hello, ' + event.queryStringParameters['Name'] + '!';
+  }
+
   return {
     statusCode: 200,
     headers: {
       'Content-Type': 'application/json',
     },
     body: JSON.stringify({
       message: responseMessage,
     }),
   }
 }